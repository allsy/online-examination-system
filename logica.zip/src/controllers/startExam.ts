import { Request, Response, NextFunction } from "express";
import { Op } from "sequelize";
import Answers from "../database/models/Answers";
import Exams from "../database/models/Exams";
import Users from "../database/models/Users";
import U_Details from "../database/models/U_Details";
import Varience from "../database/models/Varience";

const view = (req: any,res: Response,next: NextFunction)=>{

    const examId = req.params.examId;

    (async ()=>{
        const exam:any = await Exams.findOne({where:{ uniqid:examId } });
        if(!exam) return res.end('error');

        const user:any = await Users.findOne({where:{ email: req.user.email, examId:exam.id }, include: U_Details });

        if(!user){
            return res.end('error');
        }else{

            const quali = user.u_detail.qualification;
            const parti = user.u_detail.participation;

            const varience:any = await Varience.findOne({where:{ 
                qualification:quali,
                participation:parti,
                examId:exam.id            
            }, include: 'questions'});

            var newques:any;
            var prep:any[] = [];
            if(varience){
                newques = varience.questions.map((element: any)=>{

                    prep.push({id:element.id});

                    var ob={
                        id:element.id,
                        question:element.question,
                        a:element.a,
                        b:element.b,
                        c:element.c,
                        d:element.d
                    }
    
                    return ob;
    
                })
            }else{
                newques=[];
            }
            
            var ans:any = await Answers.findAll({
                where: {
                    [Op.or]: prep,
                },
              });

              if(ans){
                for(var i=0; i< newques.length; i++){
                    newques[i]['ans'] = '';

                    for(var j=0; j<ans.length; j++){
                        if(newques[i].id == ans[j].question ){
                            newques[i]['ans'] = ans[j].option
                        }
                    }
                }
              }

            return res.render('startExam',{ questions:newques, exam:exam, cuser:user });
        }
    })();

}

const post = (req: Request,res: Response,next: NextFunction)=>{

   

}


export default { view, post }