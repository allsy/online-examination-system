import { Request, Response, NextFunction } from "express";
import passport from "passport"
import Exams from "../database/models/Exams";
import Users from "../database/models/Users";

const view = (req: Request,res: Response,next: NextFunction)=>{

    const examId = req.params.examId;

    (async()=>{
        const exam:any = await Exams.findOne({ where: { uniqid: examId} });

        if(exam){
            return res.render('studentLogin',{csrfToken:req.csrfToken(),exam:exam})
        }else{
            return res.redirect('/');
        }

    })();
}

const post = (req: any,res: Response,next: NextFunction)=>{

   const examId = req.params.examId;

   var rdr:string = req.body.rdr;
   var success:string = "";

   if(rdr != undefined && rdr != ""){
       success=JSON.parse(Buffer.from(rdr, 'base64').toString()).path;
   }else{
       success=`/exam/${examId}`;
   }

   passport.authenticate('student-login',{
     successRedirect: success,
     failureRedirect: `/exam/${examId}/login?redirect=${rdr}`,
     failureFlash: true
   })(req,res,next);

}


export default { view, post }