import { Request, Response, NextFunction } from "express";
import reader from "xlsx";
import Exams from "../database/models/Exams";
import Questions from "../database/models/Questions";
import fs from "fs";
import sequelize from "sequelize";
import Varience from "../database/models/Varience";

const view = (req: any,res: Response,next: NextFunction)=>{

    const examId = req.params.uniqid;

    (async()=>{
        const exam:any = await Exams.findOne({ where: { uniqid: examId} });

        if(exam !== null){

            const papers:any = await Varience.findAll({ where: { examId: exam.id} });

            return res.render('exam',{
                csrfToken:req.csrfToken(),
                exam:exam,
                uploaded:papers
            });

        }

    })();
    
    
}

const post = (req: any,res: Response,next: NextFunction)=>{

    const examId = req.params.uniqid;

    (async ()=>{

        const exam:any = await Exams.findOne({ where: { uniqid: examId } });

        if(exam == null){
            return res.redirect('/');
        }



        const allowedQuali = ['ug','pg']
        const allowedPart = ['coding','cyber']
          // getting inputs
        const { qualification, participation } = req.body;
        const files = req.files;


        //error handling
        if(!qualification || !participation || !files)
        return res.redirect(`/college/exam/${examId}`);

        if( typeof qualification != "string" && 
            typeof participation != "string" )
            return res.redirect(`/college/exam/${examId}`);

        if(allowedQuali.indexOf(qualification) == -1 || 
        allowedPart.indexOf(participation) == -1){
            return res.redirect(`/college/exam/${examId}`);
        }

        //extracting file details
            const tempFile = files.file
            const nameArr = tempFile.name.split('.');
            const ext = nameArr[nameArr.length - 1];

            const fileName = `${Math.random().toString()}.${ext}`;
            const path=`./temp/${fileName}`

            // moving file to server
            tempFile.mv(path,(err:Error)=>{
                if(err)
                return res.status(500).send(err);


                // initiating excel file reader
                const file=reader.readFile(path);
                const sheet=file.SheetNames;

                const data:any[]=[];
                sheet.forEach(element => {

                    const tmp = reader.utils.sheet_to_json(file.Sheets[element]);
                    tmp.forEach(result => {
                        data.push(result);
                    });
                    
                });


                // Excel file error handler
                if(data.length < 1)
                return res.redirect(`/college/exam/${examId}`);

                var allowdKeys=['QUESTION','A','B','C','D','ANSWER','MARKS']

                var keys=Object.keys(data[0]);

                if(keys.length != 7)
                return res.redirect(`/college/exam/${examId}`);

                keys.forEach(element => {
                    if(allowdKeys.indexOf(element) == -1)
                    return res.redirect(`/college/exam/${examId}`);
                });

        
                // Inserting questions to database

                (async ()=>{

                    const cnf:any = await Varience.findOne({ where : {
                        qualification:qualification,
                        participation:participation,
                        examId:exam.id
                    }});

                    if(cnf){
                        
                        return res.redirect(`/college/exam/${examId}?status=success`);
                    }

                    const varience:any = await Varience.create({
                        qualification:qualification,
                        participation:participation,
                        examId:exam.id
                    });

                    
                    //converting json to database friendly columns
                const newdata = data.map((element)=>{

                    const ob = {
                        question : element.QUESTION ? element.QUESTION.toString().trim() : "",
                        a:element.A ? element.A.toString().trim(): "",
                        b:element.B ? element.B.toString().trim(): "",
                        c:element.C ? element.C.toString().trim(): "",
                        d:element.D ? element.D.toString().trim(): "",
                        answer:element.ANSWER ? element.ANSWER.toString().toLowerCase().trim(): "",
                        marks:element.MARKS ? element.MARKS.toString().trim(): "",
                        vid:varience.id
                    }

                    return ob;

                });

                    const ques:any = await Questions.bulkCreate(newdata);

                    // removing temp file
                    fs.unlinkSync(path);

                    return res.redirect(`/college/exam/${examId}?status=success`);



                })();
          

        });


    })();


}


export default { view, post }