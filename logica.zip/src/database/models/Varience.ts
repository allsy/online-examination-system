import { DataTypes } from 'sequelize'
import sequelize from "../connection"
import Exams from './Exams';

const Varience = sequelize.define('varience',{
    id:{
        type: DataTypes.INTEGER.UNSIGNED,
        autoIncrement : true,
        allowNull : false,
        primaryKey : true
    },
    qualification:{
        type: DataTypes.STRING,
        allowNull : false
    },
    participation:{
        type: DataTypes.STRING,
        allowNull : false
    },
    examId:{
        type: DataTypes.INTEGER.UNSIGNED,
        references: {model:'exams',key:'id'}
    }
},
{
timestamps:true,
paranoid:true,
});


Exams.hasMany(Varience,{foreignKey:'examId'});


export default Varience