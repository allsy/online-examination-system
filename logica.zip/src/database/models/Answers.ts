import { DataTypes } from 'sequelize'
import sequelize from "../connection"
import Questions from './Questions';
import Users from './Users';

const Answers = sequelize.define('answers',{
    id:{
        type: DataTypes.INTEGER.UNSIGNED,
        autoIncrement : true,
        allowNull : false,
        primaryKey : true
    },
    question:{
        type: DataTypes.INTEGER.UNSIGNED,
        references: {model:'questions',key:'id'}
    },
    user:{
        type: DataTypes.INTEGER.UNSIGNED,
        references: {model:'users',key:'id'}
    },
    option:{
        type: DataTypes.CHAR(1),
        allowNull: false
    }
},
{
timestamps:true,
paranoid:true,
});

Questions.hasMany(Answers,{foreignKey:'question'});
Questions.hasMany(Users,{foreignKey:'user'});

export default Answers