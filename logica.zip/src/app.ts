// importing core modules
import express, {Application, NextFunction, Request, Response} from 'express';

// importing config
import config from './config/config';


// importing third party modules
import passport from 'passport';
import session from 'express-session';
import cookieParser from 'cookie-parser';
import csurf from 'csurf';
import flash from "connect-flash"
import fileUpload from 'express-fileupload';

const csrfProtection=csurf({cookie:true});


// initializing express app
const app: Application = express();

// setting view engine and static files directory
app.set("view engine","ejs")
app.use(express.static('./public'))


// passport strategy
import strategy from "./config/passport"
strategy(passport)

// setting session and cookie parser 
app.use(cookieParser('dsf5ds5f5dsfd'));
app.use(session({
    secret:'dsf5ds5f5dsfd',
    resave:true,
    saveUninitialized:true
}));
app.use(flash())


//passport extra
app.use(passport.initialize());
app.use(passport.session());


 //global variables
 app.use((req:Request, res:Response, next:NextFunction)=>{
    res.locals.success_msg= req.flash('success_msg');
    res.locals.error= req.flash('error');
    res.locals.message= req.flash('message');
    res.locals.user = req.user
    next();
});


//custom csrf message
app.use(function (err:any, req:Request, res:Response, next:NextFunction) {
    if (err.code !== 'EBADCSRFTOKEN') return next(err)
   
    // handle CSRF token errors here
    res.status(403)
    res.send('unauthorised access');
});


//setting body parser
app.use(express.urlencoded({limit:'10mb',extended: true }));
app.use(express.json({limit:'10mb'}));
app.use(fileUpload({
    createParentPath: true
}));


// importing controllers
import collegeLogincontroller from "./controllers/collegeLogin";
import dashboardController from "./controllers/dashboard";
import startExamController from "./controllers/startExam";
import collegeController from "./controllers/college";
import examController from "./controllers/exam";
import studentLoginController from "./controllers/studentLogin";
import homeController from "./controllers/home";


//importing middlewares
import isAuth from "./config/isAuth";
import notAuth from "./config/notAuth";
import isCollege from "./config/isCollege";
import isStudent from "./config/isStudent";

import bcrypt from "bcryptjs";

// Routes

//college user login
app.route( '/' )
.get(homeController.view);

import data from "./config/data";

app.get('/xyz/fetch',(req:any, res:Response, next:NextFunction)=>{

const allowed:any = data.approved;
const paid:any = data.payments;
const user:any = data.users;

const neww: any[]= [];

const ak = Object.keys(allowed);

 for(var i=0; i< ak.length; i++){
    neww.push({
        uuid:Math.random().toString(),
        name: user[ ak[i] ].name.toString(),
        email: user[ ak[i] ].email.toString(),
        phone: user[ ak[i]].phone.toString(),
        stream: user[ ak[i] ].phone.toString(),
        qualification : user[ ak[i] ].status == 'post_graduate' ? 'pg' : 'ug',
        participation: paid[ ak[i] ].participation == 'coding' ? 'coding' : 'cyber',
        college : user[ ak[i] ].college_name.toString(),
        city: user[ ak[i] ].city.toString()
    });
 }



 (async ()=>{


    const allnew = neww.map((element)=>{

        var ob=element;
    
        var nn = element.name.substring(0,2);
        var pp = element.phone.substr(-4, 4);
    
        var kk =nn+pp;
    
        ob['password'] = kk;
    
        return ob;
     })

    for(var j=0; j<allnew.length; j++){

        const us:any = await Users.create({
            email: allnew[j].email,
            password:allnew[j].password,
            examId:1,
            type:'0'
        })

        const ud= await U_Details.create({
            name: allnew[j].name,
            college: allnew[j].college,
            city: allnew[j].city,
            phone: allnew[j].phone,
            stream:allnew[j].stream,
            qualification:allnew[j].qualification,
            participation:allnew[j].participation,
            userId : us.id
        })

        
    }


    res.send("done")

     
 })();


});


app.route( '/college/login' )
.get( notAuth, csrfProtection, collegeLogincontroller.view )
.post( notAuth, csrfProtection, collegeLogincontroller.post )

//logout
app.get('/logout',(req:any,res:Response,next:NextFunction)=>{

    req.logout(()=>{
        res.redirect('/');
    });
});

// users redirection
app.route( '/dashboard' )
.get( isAuth, csrfProtection, dashboardController.view )


// college user
app.route( '/college' )
.get( isCollege, csrfProtection, collegeController.view )
.post( isCollege, csrfProtection, collegeController.post )

//
app.route('/college/exam/:uniqid')
.get(isCollege, csrfProtection, examController.view)
.post(isCollege, csrfProtection, examController.post)



//student Login
app.route('/exam/:examId/login')
.get(notAuth, csrfProtection, studentLoginController.view)
.post(notAuth, csrfProtection, studentLoginController.post)


// student user
app.route('/exam/:examId')
.get( isStudent, csrfProtection, startExamController.view )
.post( isStudent, csrfProtection, startExamController.post )



// starting server
const server = app.listen(config.server.port,()=> console.log("server is running"));


//generating tables
import dbInit from './database/init';
dbInit();

//initiating socket
import initiate from './config/socket';
import Users from './database/models/Users';
import U_Details from './database/models/U_Details';
initiate(server);





