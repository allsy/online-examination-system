import { Server } from "socket.io";
import Answers from "../database/models/Answers";
import Exams from "../database/models/Exams";
import Users from "../database/models/Users";


function initiate(server:any){
    const io = new Server(server,{

    });
    
    io.use((socket, next) => {
        (async ()=>{
            const token = socket.handshake.auth;
    
            const exam:any = await Exams.findOne({ where:{ uniqid:token.examId} });
            if(exam){
                const user:any = await Users.findOne({ where:{ uuid:token.uid, examId:exam.id } });
                if(user){
    
                    next();
                    socket.join(token.uid);
                }else{
                    next(new Error('Unauthorized Access'));
                }
            }else{
                next(new Error('Unauthorized Access'));
            }
    
        })();
      });
    
    io.on('connection',(socket)=>{
    
        socket.on('marked',function(qid,uid,eid,val){

            (async ()=>{

                const exam:any = await Exams.findOne({where:{uniqid:eid}});
                if(exam){

                    const starting = exam.starting;
                    const st = Date.parse(starting);
                    const nt = Date.now();
                    const duration = exam.duration;
                    
                    if(nt - st > (duration * 60 * 1000)){

                        io.sockets.in(uid).emit('examended');
                        return;
                    }else{

                        const user:any = await Users.findOne({where:{uuid:uid, examId: exam.id }});

                    if(user){

                        const ans:any = await Answers.findOne({where:{ question:qid, user:user.id }});
                        if(ans){
                            await Answers.update({option:val},{where:{ user:user.id, question:qid}});
                        }else{
                            await Answers.create({
                                question:qid,
                                user:user.id,
                                option:val
                            })
                        }
                    }

                    }

                }

            })();
          
        });

        socket.on('submit',function(uuid,examid,details){

            io.sockets.in(uuid).emit('submitted');
            
        });

        socket.on('startrequest',function(uuid,examid){

            (async ()=>{
                const exam:any = await Exams.findOne({where:{uniqid:examid}});
                if(exam){
                    const starting = exam.starting;
                    const st = Date.parse(starting);
                    const nt = Date.now();
                    if(nt - st > 0){

                        io.sockets.in(uuid).emit('start');
                    }
                    else{
                        io.sockets.in(uuid).emit('notstarted');
                    }
                }

            })();

        });
    
        socket.on('compatible',function(){
    
            
          
        });
    
    });
}

export default initiate